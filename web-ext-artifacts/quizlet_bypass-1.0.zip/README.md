# Quizlet-Bypass
Hi! This extension requires Firefox, because creating Chrome extensions that are... simply put, not in favour of large corporations is very difficult.