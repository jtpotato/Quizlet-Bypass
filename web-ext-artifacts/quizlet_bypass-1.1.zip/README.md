# Quizlet-Bypass
Hi! This extension requires Firefox, because creating Chrome extensions that are... simply put, not in favour of large corporations is very difficult.

Download here:
https://github.com/jtpotato/Quizlet-Bypass/releases/download/1.0/quizlet_bypass-1.0-an.xpi

## For nerds:
If you're interested, here's how it works.

- We redirect clicks on the "Flashcards", "Learn", "Test" and "Match" buttons to their embed links.
  - Embeds can be used without signing in - as long as we block the sign-in popup.